#!/bin/sh
echo -ne '\033c\033]0;Semmel-Defender\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/Fischsemmeldef_fixed.x86_64" "$@"
